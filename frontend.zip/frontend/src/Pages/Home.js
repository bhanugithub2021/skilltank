import React from "react";
import { Link } from "react-router-dom";
import "../App.css";
import Avatar from "react-avatar";
import SemiCircle from "../assets/semicircle.png";
import Arrow from "../assets/curved.png";
import dellars from "../assets/dollars.png";
import girl from "../assets/girl.png";
import stand from "../assets/stand.png";
import spring from "../assets/spring.png";
import wave from "../assets/wave.png";

function Home() {
  return (
    <div className="container">
      <div className="first-box">
        <div className="column-one">
          <h1 className="head-text">
            Getting you <span className="icon-circle">4.9</span>
            <br />{" "}
            <Avatar googleId="118096717852922241760" size="40" round={true} />
            <span className="semicircle">
              <div className="image-container">
                <img
                  className="imgcircle"
                  src={SemiCircle}
                  width={50}
                  style={{
                    filter: "sepia(100%) saturate(1000%) hue-rotate(-2deg)",
                    transform: "rotate(136deg)",
                  }}
                />

                <p className="image-text">12%</p>
              </div>
            </span>
            Where you <br />
            want to study.
            <img
              src={Arrow}
              width={40}
              style={{ transform: "rotate(188deg)", marginLeft: "5px" }}
            />
          </h1>
          <p className="para-text">
            Everything you need to know for your study
            <br /> abroad journey: from first search to your first day
            <br /> on campus.
          </p>
        </div>
        <div className="column-two">
          <nav>
            <div class="nav nav-tabs" id="nav-tab" role="tablist">
              <a
                class="nav-link active"
                id="nav-Courses-tab"
                data-bs-toggle="tab"
                href="#nav-home"
                role="tab"
                aria-controls="nav-home"
                aria-selected="true"
              >
                Courses
              </a>
              <a
                class="nav-link"
                id="nav-profile-tab"
                data-bs-toggle="tab"
                href="#nav-profile"
                role="tab"
                aria-controls="nav-profile"
                aria-selected="false"
              >
                Services
              </a>
            </div>
          </nav>
          <div class="tab-content" id="nav-tabContent">
            <div
              class="tab-pane fade show active"
              id="nav-home"
              role="tabpanel"
              aria-labelledby="nav-home-tab"
            >
              <form class="form-floating">
                <input
                  type="email"
                  class="form-control"
                  id="floatingInputValue"
                  placeholder="name@example.com"
                />
                <label for="floatingInputValue">Input with value</label>
              </form>
              <form class="form-floating">
                <input
                  type="email"
                  class="form-control"
                  id="floatingInputValue"
                  placeholder="name@example.com"
                />
                <label for="floatingInputValue">Input with value</label>
              </form>
            </div>

            <div
              class="tab-pane fade"
              id="nav-profile"
              role="tabpanel"
              aria-labelledby="nav-profile-tab"
            >
              <p>clicked Services</p>
            </div>
          </div>
        </div>
      </div>
      <div className="second-box">
        <div className="box-a">
          {" "}
          <h1 className="second-head">
            Empowering
            <br /> Education
            <br /> Through
            <br /> Innovation
          </h1>
          <div className="std-wrap">
            <div className="total-student">
              <div className="dlr-circle">
                <img
                  src={dellars}
                  width={30}
                  style={{ filter: "brightness(0) invert(1)" }}
                />
              </div>

              <h1 className="total-title">Total Students</h1>
              <span className="rate">159.89</span>
            </div>
            <div className="cicle-bulb">
              <div className="girl-wrap">
                <img src={girl} width={200} />
              </div>
              <div className="stand-botton">
                <img src={stand} width={160} />
              </div>
            </div>
          </div>
        </div>
        <div className="box-b">
          <div className="univercity">
            <div className="fist-ring">
              <div>
                <p class="Project_Analytics_Heading text-center">
                  World Top university
                </p>
                <svg viewBox="0 0 36 36" class="circular-chart">
                  <path
                    class="that-circle"
                    stroke="#ecf0f1"
                    stroke-dasharray="100 50"
                    d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                  />

                  <path
                    class="that-circle"
                    stroke="#fd79a8"
                    stroke-dasharray="75"
                    d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                  />

                  <path
                    class="that-circle"
                    stroke="#845cee"
                    stroke-dasharray="25 100"
                    d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                  />

                  <text x="18" y="20.35" class="percentage">
                    10
                  </text>
                  <text x="13" y="25" class="percentage_done">
                    Ranking
                  </text>
                </svg>
                <svg viewBox="0 0 36 36" class="circular-chart2">
                  <path
                    class="that-circle"
                    stroke="#ecf0f1"
                    stroke-dasharray="100"
                    d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                  <path
                    class="that-circle"
                    stroke="yellow"
                    stroke-dasharray="50"
                    d="M18 2.0845
                                a 15.9155 15.9155 0 0 1 0 31.831
                                a 15.9155 15.9155 0 0 1 0 -31.831"
                  />
                </svg>
              </div>
            </div>
            <div className="second-ring">
              <span className="first-report"></span>
              <p className="report-text">Graphic Templates</p>
              <span className="second-report"></span>
              <p className="report-text">UI Design</p>
            </div>
          </div>
          <div className="report">
            <p class="Project_Analytics_Heading text-center">Earning Report</p>
            <div className="student-report">
              <div className="circle-first">
                <img
                  src={dellars}
                  width={30}
                  style={{ filter: "brightness(0) invert(1)" }}
                />
              </div>

              <h1 className="student-title">Total Students</h1>
              <span className="student-rate">78K</span>
            </div>

            <div className="student-report">
              <div className="circle-first" style={{ background: "#70a1ff" }}>
                <img
                  src={dellars}
                  width={30}
                  style={{ filter: "brightness(0) invert(1)" }}
                />
              </div>

              <h1 className="student-title"> BD Toppers Students</h1>
              <span className="student-rate"> 8K</span>
            </div>

            <div className="student-report">
              <div className="circle-first">
                <img
                  src={dellars}
                  width={30}
                  style={{ filter: "brightness(0) invert(1)" }}
                />
              </div>

              <h1 className="student-title">Contributor Bobus</h1>
              <span className="student-rate">706</span>
            </div>
          </div>
        </div>
        <div className="footer-style">
          <div>
            <img
              className="sring-image"
              src={spring}
              width={100}
              style={{
                filter: "sepia(100%) saturate(1000%) hue-rotate(231deg)",
                transform: "rotate(15deg)",
              }}
            />
          </div>

          <div>
            {" "}
            <img className="wave-image" src={wave} width={200} />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;
