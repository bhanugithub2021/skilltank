import React from "react";
import { Link } from "react-router-dom";
import "../App.css";
import { TbRouteAltRight } from "react-icons/tb";
import { HiBars3 } from "react-icons/hi2";
import { MdFlight } from "react-icons/md";

function CustomeHeader() {
  return (
    <>
      <header>
        <nav>
          <ul>
            <li>
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/">Officers</Link>
            </li>
            <li>
              <Link to="/">Examination</Link>
            </li>
            <li>
              <Link to="/">Sections</Link>
            </li>
            <li>
              <Link to="/">Students</Link>
            </li>
            <li>
              <Link to="/">Academics</Link>
            </li>
            <li>
              <span className="rout"> <Link to="/"> <TbRouteAltRight /></Link></span>

            </li>
            <li>
              <span className="rout"><Link to="/"> <MdFlight /></Link></span>
            </li>
            <li>
              <Link to="/"> <HiBars3 /></Link>
            </li>

          </ul>
        </nav>
      </header>
      <main>
        <p>Hello, this is your dashboard content!</p>
      </main>

    </>
  );
}

export default CustomeHeader;
